/* @ds-bundle: {"format":4,"namespace":"AusUltraDesignSystem_98e6b4","components":[{"name":"FeatureItem","sourcePath":"components/cards/FeatureItem.jsx"},{"name":"ProjectCard","sourcePath":"components/cards/ProjectCard.jsx"},{"name":"ServiceCard","sourcePath":"components/cards/ServiceCard.jsx"},{"name":"TestimonialCard","sourcePath":"components/cards/TestimonialCard.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Badge","sourcePath":"components/misc/Badge.jsx"},{"name":"Icon","sourcePath":"components/misc/Icon.jsx"},{"name":"SocialIconButton","sourcePath":"components/misc/SocialIconButton.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/cards/FeatureItem.jsx":"b81ffaa3f8d9","components/cards/ProjectCard.jsx":"4d3e51a5c1f7","components/cards/ServiceCard.jsx":"1f25024ae927","components/cards/TestimonialCard.jsx":"ce4766ceed6d","components/core/Button.jsx":"c0e7cf9354d3","components/misc/Badge.jsx":"c1a481f0c1c5","components/misc/Icon.jsx":"4856205c1c2a","components/misc/SocialIconButton.jsx":"5d3bbef2747a","components/navigation/Footer.jsx":"bb84fc41995b","components/navigation/NavBar.jsx":"4b4df1e1803a","ui_kits/website/Homepage.jsx":"df1b16d8105d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AusUltraDesignSystem_98e6b4 = window.AusUltraDesignSystem_98e6b4 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/misc/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  strokeWidth = 1.75,
  style
}) {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [name]);
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      color,
      display: 'inline-block',
      ...style
    },
    "data-stroke-width": strokeWidth
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Icon.jsx", error: String((e && e.message) || e) }); }

// components/cards/FeatureItem.jsx
try { (() => {
function FeatureItem({
  icon,
  title,
  description
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-start',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 26,
    color: "var(--color-primary)",
    strokeWidth: 1.5
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 15,
      marginBottom: 4
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--color-text-body)',
      fontSize: 13.5,
      lineHeight: 1.6
    }
  }, description)));
}
Object.assign(__ds_scope, { FeatureItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/FeatureItem.jsx", error: String((e && e.message) || e) }); }

// components/cards/ProjectCard.jsx
try { (() => {
function ProjectCard({
  image,
  title,
  location
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/3',
      overflow: 'hidden',
      borderRadius: 'var(--radius-sm)',
      border: 'var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      transform: hover ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform var(--duration-base) var(--ease-standard)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      padding: '12px 2px 0',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontSize: 14,
      fontWeight: 500
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--color-text-muted)',
      fontSize: 12,
      marginTop: 2
    }
  }, location)), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 16,
    color: hover ? 'var(--color-primary)' : 'var(--color-text-muted)',
    style: {
      marginTop: 3
    }
  })));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ServiceCard.jsx
try { (() => {
function ServiceCard({
  image,
  icon,
  title
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      border: 'var(--border-hairline)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      background: 'var(--color-surface)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/3',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '14px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "var(--color-primary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 500,
      color: '#fff'
    }
  }, title)), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 16,
    color: hover ? 'var(--color-primary)' : 'var(--color-text-muted)'
  })));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/TestimonialCard.jsx
try { (() => {
function TestimonialCard({
  quote,
  author,
  rating = 5,
  onPrev,
  onNext
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface)',
      border: 'var(--border-hairline)',
      borderRadius: 'var(--radius-md)',
      padding: '28px 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      fontFamily: 'var(--font-body)',
      maxWidth: 460
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "quote",
    size: 22,
    color: "var(--color-primary)"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--color-text-body)',
      fontSize: 14.5,
      lineHeight: 1.6,
      margin: 0
    }
  }, quote), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 2,
      marginBottom: 6
    }
  }, Array.from({
    length: 5
  }).map((_, i) => /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    key: i,
    name: "star",
    size: 14,
    color: i < rating ? 'var(--color-primary)' : 'var(--color-border-strong)'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontSize: 13
    }
  }, author)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onPrev,
    style: {
      width: 32,
      height: 32,
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--color-border-strong)',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-left",
    size: 14
  })), /*#__PURE__*/React.createElement("button", {
    onClick: onNext,
    style: {
      width: 32,
      height: 32,
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--color-border-strong)',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 14
  })))));
}
Object.assign(__ds_scope, { TestimonialCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/TestimonialCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  disabled,
  icon = 'arrow-right',
  children
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 10,
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: size === 'sm' ? 13 : 14,
    padding: size === 'sm' ? '10px 18px' : '14px 24px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    textDecoration: 'none',
    transition: 'background var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)'
  };
  const variants = {
    primary: {
      background: 'var(--color-primary)',
      color: '#1a1210',
      borderColor: 'var(--color-primary)'
    },
    secondary: {
      background: 'transparent',
      color: '#fff',
      borderColor: 'var(--color-border-strong)'
    }
  };
  const hover = {
    primary: {
      background: 'var(--color-primary-hover)',
      borderColor: 'var(--color-primary-hover)'
    },
    secondary: {
      background: 'var(--color-surface)',
      borderColor: '#fff'
    }
  };
  const [isHover, setHover] = React.useState(false);
  const style = {
    ...base,
    ...variants[variant],
    ...(isHover && !disabled ? hover[variant] : {})
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, {
    href: href,
    onClick: disabled ? undefined : onClick,
    disabled: Tag === 'button' ? disabled : undefined,
    style: style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, children, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/misc/Badge.jsx
try { (() => {
function Badge({
  icon,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20,
    color: "var(--color-primary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff',
      fontSize: 13,
      lineHeight: 1.3
    }
  }, children));
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Badge.jsx", error: String((e && e.message) || e) }); }

// components/misc/SocialIconButton.jsx
try { (() => {
const glyphs = {
  facebook: 'M13.5 21v-7h2.4l.4-3H13.5V9.2c0-.87.24-1.46 1.5-1.46h1.6V5.14C16.1 5.1 15.1 5 13.9 5 11.4 5 9.7 6.49 9.7 9.02V11H7.3v3h2.4v7h3.8Z',
  instagram: 'M8 3h8a5 5 0 0 1 5 5v8a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3H8Zm4 3.2A3.8 3.8 0 1 1 8.2 12 3.8 3.8 0 0 1 12 8.2Zm0 2A1.8 1.8 0 1 0 13.8 12 1.8 1.8 0 0 0 12 10.2ZM17.1 6.4a1 1 0 1 1-1 1 1 1 0 0 1 1-1Z'
};
function SocialIconButton({
  icon,
  href = '#'
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 36,
      height: 36,
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--color-border-strong)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: hover ? 'var(--color-primary)' : 'transparent',
      borderColor: hover ? 'var(--color-primary)' : 'var(--color-border-strong)',
      transition: 'background var(--duration-fast) var(--ease-standard)'
    }
  }, glyphs[icon] ? /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: hover ? '#1a1210' : '#fff'
  }, /*#__PURE__*/React.createElement("path", {
    d: glyphs[icon]
  })) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: hover ? '#1a1210' : '#fff'
  }));
}
Object.assign(__ds_scope, { SocialIconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/SocialIconButton.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
const columns = {
  'Quick Links': ['Home', 'Services', 'Projects', 'About', 'Contact'],
  'Our Services': ['Concrete & Driveways', 'Retaining Walls', 'Front Yard Elevations', 'Backyard Transformations', 'Fencing', 'Turf Installation', 'Epoxy Coatings', 'Epoxy Flake Flooring']
};
function Footer({
  logo = '../../assets/logo.png',
  phone = '0415 795 055',
  email = 'AusUltraLandscaping@gmail.com',
  location = 'Brisbane, QLD'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-bg)',
      borderTop: 'var(--border-hairline)',
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1fr',
      gap: 32,
      padding: '48px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "AusUltra Landscaping",
    style: {
      height: 32,
      marginBottom: 14
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      lineHeight: 1.7,
      maxWidth: 260
    }
  }, "Premium landscaping, concrete, retaining walls, fencing and outdoor transformations across Brisbane."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SocialIconButton, {
    icon: "facebook"
  }), /*#__PURE__*/React.createElement(__ds_scope.SocialIconButton, {
    icon: "instagram"
  }))), Object.entries(columns).map(([heading, items]) => /*#__PURE__*/React.createElement("div", {
    key: heading
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 14,
      marginBottom: 14
    }
  }, heading), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it,
    href: "#",
    style: {
      color: 'var(--color-text-body)',
      fontSize: 13,
      textDecoration: 'none'
    }
  }, it))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 14,
      marginBottom: 14
    }
  }, "Get In Touch"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "phone",
    size: 14,
    color: "var(--color-primary)"
  }), phone), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "mail",
    size: 14,
    color: "var(--color-primary)"
  }), email), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "map-pin",
    size: 14,
    color: "var(--color-primary)"
  }), location)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm"
  }, "Get a Quote")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: '16px 32px',
      borderTop: 'var(--border-hairline)',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, "\xA9 2024 AusUltra Landscaping. All rights reserved."), /*#__PURE__*/React.createElement("div", {
    style: {
      letterSpacing: 'var(--tracking-wider)',
      textTransform: 'uppercase'
    }
  }, "Quality Spaces. Stronger Tomorrows.")));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  logo = '../../assets/logo.png',
  links = ['Home', 'Services', 'Projects', 'About', 'Contact'],
  activeLink = 'Home',
  phone = '0415 795 055'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px 32px',
      background: 'var(--color-bg)',
      borderBottom: 'var(--border-hairline)',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "AusUltra Landscaping",
    style: {
      height: 34
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      color: l === activeLink ? 'var(--color-primary)' : '#fff',
      textDecoration: 'none',
      fontSize: 14,
      fontWeight: 500,
      borderBottom: l === activeLink ? '2px solid var(--color-primary)' : '2px solid transparent',
      paddingBottom: 4
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      color: '#fff',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "phone",
    size: 15,
    color: "var(--color-primary)"
  }), phone), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm"
  }, "Get a Quote")));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Homepage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  NavBar,
  Footer,
  Badge,
  ServiceCard,
  ProjectCard,
  FeatureItem,
  TestimonialCard,
  Button,
  Icon
} = window.AusUltraDesignSystem_98e6b4;
const services = [{
  icon: 'milestone',
  title: 'Concrete Sidewalks & Driveways',
  image: '../../assets/project-driveway.jpg'
}, {
  icon: 'brick-wall',
  title: 'Retaining Walls',
  image: '../../assets/project-retaining-wall.jpg'
}, {
  icon: 'home',
  title: 'House Front Elevations',
  image: '../../assets/hero-photo.jpg'
}, {
  icon: 'trees',
  title: 'Backyard Transformation',
  image: '../../assets/hero-photo.jpg'
}, {
  icon: 'fence',
  title: 'Timber & Colorbond Fencing',
  image: '../../assets/project-retaining-wall.jpg'
}, {
  icon: 'sprout',
  title: 'Artificial/Natural Turf Installation',
  image: '../../assets/texture-pathway.jpg'
}, {
  icon: 'layers',
  title: 'Epoxy Coatings',
  image: '../../assets/project-driveway.jpg'
}, {
  icon: 'grid-2x2',
  title: 'Epoxy Flake Flooring',
  image: '../../assets/project-driveway.jpg'
}];
const projects = [{
  title: 'Concrete Driveway',
  location: 'Brisbane, QLD',
  image: '../../assets/project-driveway.jpg'
}, {
  title: 'Retaining Wall',
  location: 'Brisbane, QLD',
  image: '../../assets/project-retaining-wall.jpg'
}, {
  title: 'Backyard Transformation',
  location: 'Brisbane, QLD',
  image: '../../assets/hero-photo.jpg'
}, {
  title: 'Turf Installation',
  location: 'Brisbane, QLD',
  image: '../../assets/texture-pathway.jpg'
}];
const testimonials = [{
  quote: 'AusUltra did an amazing job on our backyard. Professional, reliable and the quality is top notch. Highly recommend!',
  author: '— Brisbane Client',
  rating: 4
}, {
  quote: 'From the quote to the finished driveway, everything was on time and exactly as promised. Couldn\u2019t be happier.',
  author: '— Brisbane Client',
  rating: 5
}, {
  quote: 'Our retaining wall looks incredible and the whole crew was easy to deal with from start to finish.',
  author: '— Brisbane Client',
  rating: 5
}];
function Homepage() {
  const [tIndex, setTIndex] = React.useState(0);
  const t = testimonials[tIndex];
  const next = () => setTIndex(i => (i + 1) % testimonials.length);
  const prev = () => setTIndex(i => (i - 1 + testimonials.length) % testimonials.length);
  const section = {
    padding: '72px 32px',
    maxWidth: 1280,
    margin: '0 auto'
  };
  const eyebrow = {
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: 12,
    letterSpacing: 'var(--tracking-wider)',
    textTransform: 'uppercase',
    color: 'var(--color-primary)',
    marginBottom: 12
  };
  const h2 = {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: 'clamp(1.6rem,3vw,2.1rem)',
    lineHeight: 1.1,
    textTransform: 'uppercase',
    color: '#fff',
    margin: 0
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-bg)',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    activeLink: "Home"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: '56px 32px 64px',
      maxWidth: 1280,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 40,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: eyebrow
  }, "Brisbane Landscaping Experts"), /*#__PURE__*/React.createElement("h1", {
    style: {
      ...h2,
      fontSize: 'clamp(2rem,4.5vw,3.1rem)',
      marginBottom: 20
    }
  }, "Transforming", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-primary)'
    }
  }, "Outdoor Spaces.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)',
      fontSize: 15.5,
      lineHeight: 1.7,
      maxWidth: 440,
      marginBottom: 32
    }
  }, "Concrete, retaining walls, fencing, turf and complete landscaping solutions. Built to last."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginBottom: 44
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Get a Free Quote"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "play"
  }, "View Our Work")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 36
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    icon: "shield-check"
  }, "Quality Workmanship"), /*#__PURE__*/React.createElement(Badge, {
    icon: "calendar"
  }, "On Time & Reliable"), /*#__PURE__*/React.createElement(Badge, {
    icon: "users"
  }, "Local Brisbane Business"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      border: 'var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/hero-photo.jpg",
    alt: "Landscaped outdoor steps",
    style: {
      width: '100%',
      display: 'block'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: section
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      marginBottom: 40,
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: eyebrow
  }, "Our Services"), /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Landscaping", /*#__PURE__*/React.createElement("br", null), "Solutions", /*#__PURE__*/React.createElement("br", null), "Built For You.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)',
      fontSize: 14,
      maxWidth: 320,
      lineHeight: 1.6
    }
  }, "From concrete driveways to complete backyard transformations, AusUltra Landscaping delivers high-quality, functional and modern outdoor spaces across Brisbane and surrounding areas."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "View All Services")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 20
    }
  }, services.map(s => /*#__PURE__*/React.createElement(ServiceCard, _extends({
    key: s.title
  }, s))))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...section,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: eyebrow
  }, "Why Choose AusUltra"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...h2,
      marginBottom: 18
    }
  }, "More Than", /*#__PURE__*/React.createElement("br", null), "Landscaping."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)',
      fontSize: 14.5,
      lineHeight: 1.7,
      marginBottom: 14
    }
  }, "We take pride in delivering high-quality landscaping solutions that enhance your home, add value and are built to last."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)',
      fontSize: 14.5,
      lineHeight: 1.7,
      marginBottom: 28
    }
  }, "From concept to completion, we focus on quality, reliability and attention to detail."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "About Us")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 26
    }
  }, /*#__PURE__*/React.createElement(FeatureItem, {
    icon: "gem",
    title: "High Quality Materials",
    description: "We use durable, premium materials for a long-lasting finish."
  }), /*#__PURE__*/React.createElement(FeatureItem, {
    icon: "handshake",
    title: "Reliable & Professional",
    description: "Clear communication and on-time delivery."
  }), /*#__PURE__*/React.createElement(FeatureItem, {
    icon: "map-pin",
    title: "Local Brisbane Experts",
    description: "Proudly serving Brisbane and surrounding areas."
  }))), /*#__PURE__*/React.createElement("div", {
    style: section
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: eyebrow
  }, "Our Work"), /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Recent ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-primary)'
    }
  }, "Projects")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--color-text-body)',
      fontSize: 14,
      marginTop: 10
    }
  }, "See the difference a well-designed outdoor space can make.")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "View All Projects")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 20
    }
  }, projects.map(p => /*#__PURE__*/React.createElement(ProjectCard, _extends({
    key: p.title
  }, p))))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...section,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: eyebrow
  }, "What Our Clients Say"), /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Trusted By", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-primary)'
    }
  }, "Brisbane Homeowners."))), /*#__PURE__*/React.createElement(TestimonialCard, _extends({}, t, {
    onPrev: prev,
    onNext: next
  }))), /*#__PURE__*/React.createElement(Footer, null));
}
window.Homepage = Homepage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Homepage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.FeatureItem = __ds_scope.FeatureItem;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.TestimonialCard = __ds_scope.TestimonialCard;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.SocialIconButton = __ds_scope.SocialIconButton;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
