# AusUltra Design System

## Overview
AusUltra Landscaping is a Brisbane-based landscaping and hardscaping contractor: concrete driveways, retaining walls, fencing, turf, epoxy flooring, backyard transformations. This design system is built from the company's marketing website.

## Source
- Uploaded file: `uploads/AusUltra Design System.png` — full-page screenshot of the AusUltra Landscaping homepage (nav, hero, services grid, "why choose us", recent projects, testimonials, footer).
- No codebase, Figma file, or slide deck was provided. Everything here is derived from that one screenshot. If a live site codebase or Figma file exists, attach it and this system can be rebuilt against real component source instead of a screenshot.

## Product
One product: the AusUltra Landscaping marketing website. Services covered: concrete sidewalks & driveways, retaining walls, house front elevations, backyard transformation, timber & colorbond fencing, artificial/natural turf, epoxy coatings, epoxy flake flooring.

## Content fundamentals
- **Voice**: direct, benefits-first trade-services tone. Short punchy headline fragments in caps ("TRANSFORMING OUTDOOR SPACES.") followed by one plain supporting sentence.
- **Address**: "we/our" for the company, speaks to "you" the homeowner ("delivers ... for you"). No first-person-singular.
- **Casing**: headlines ALL CAPS, two lines, second line in accent orange. Eyebrow labels ("OUR SERVICES", "WHY CHOOSE AUSULTRA") are small-caps with wide letter-spacing, orange.
- **Sentences**: short and concrete, trade nouns — "Concrete, retaining walls, fencing, turf and complete landscaping solutions. Built to last." No jargon, no humor, no emoji anywhere.
- **Social proof**: star rating + one short client quote, attributed generically ("— Brisbane Client"), not by full name.
- **CTAs**: imperative and short — "Get a Free Quote", "View Our Work", "About Us", "View All Services/Projects".
- **Tagline**: "QUALITY SPACES. STRONGER TOMORROWS." in the footer bar.

## Visual foundations
- **Palette**: near-black background (`#0d0f0f`) end to end — no light sections anywhere on the site. One accent: warm copper-orange (`#c17a45`) for headline second lines, icons, buttons, eyebrow labels. Primary headline line is white; body copy is a muted warm gray (`#a8adad`), not pure white — keeps a fully-dark site from feeling harsh.
- **Type**: bold, tight, all-caps display face for headings; plain grotesque body copy at regular weight with roomy line-height. See font substitution below.
- **Spacing**: generous section padding, tighter card interiors; 2- and 4-column grids for services/projects.
- **Imagery**: warm, moody dusk/golden-hour photography of real landscaping projects, low-key exposure, warm practical lighting (string/step lights). No bright daylight or stock-white shots.
- **Backgrounds**: flat dark color only — no gradients, no patterns/textures, no blur. One full-bleed photographic hero; other photos sit inside bordered cards, not full-bleed.
- **Borders**: thin 1px hairline borders (outline buttons, photo-card frames) do the separation work instead of shadows.
- **Corner radii**: small and consistent, ~6–8px on buttons/cards (icon badges are the only fully round shapes).
- **Cards**: photo on top, hairline border, dark surface fill, icon + label row at the bottom, no drop shadow.
- **Icons**: small circular outline icons (~36–40px), thin stroke, orange stroke color, no fill.
- **Buttons**: primary = solid orange fill + arrow suffix; secondary = 1px light outline, transparent fill + arrow suffix. Neither has a shadow.
- **Motion**: none visible in the static source — treated as none rather than invented.
- **Depth**: no elevation shadows anywhere; flatness + hairline borders carry all visual separation.
- **Transparency / blur**: none observed in the source.

## Iconography
- Small circular outline icons throughout: shield, calendar, users; diamond, handshake, map-pin; road, wall, house, leaf, fence, grass, layers, tile-grid; phone, mail, location; facebook, instagram.
- No icon font or SVG sprite was included in the source. **Substituted with Lucide** (closest CDN match for stroke weight/style) — flagged; swap in the real icon set if one exists.
- No emoji anywhere in the source.

## Font substitution — FLAGGED
No font files were provided. The headline caps read as a bold geometric/grotesque sans; body copy as a plain grotesque. Substituted **Poppins** (display, 700/800) and **Inter** (body) via Google Fonts, declared in `tokens/typography.css`. If AusUltra uses a licensed or custom typeface, please share the font files and these will be swapped in.

## Logo
Cropped directly from the source screenshot (`assets/logo.png`): a house-and-tree mark beside the "AUSULTRA" wordmark (white + orange) with "LANDSCAPING" as a small tracked-out orange subtitle. No vector original was provided — this is a raster stand-in. Please share the original logo file (SVG/AI/EPS) for a clean vector mark at any size.

## Index
- `styles.css` — global stylesheet entry point (imports all tokens below)
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`
- `assets/` — `logo.png`, `hero-photo.jpg`, `project-driveway.jpg`, `project-retaining-wall.jpg`, `texture-pathway.jpg` (all cropped from the source screenshot)
- `components/core/` — `Button`
- `components/misc/` — `Badge`, `SocialIconButton`
- `components/cards/` — `ServiceCard`, `ProjectCard`, `TestimonialCard`, `FeatureItem`
- `components/navigation/` — `NavBar`, `Footer`
- `ui_kits/website/` — full homepage recreation, `index.html`
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand)
- `SKILL.md` — portable skill file for Claude Code

## Intentional additions
- `Badge` (icon + label pill, hero trust strip) and `SocialIconButton` (circular footer icon button) are small primitives implied by the source layout but not separately callable there; added here for reuse.
