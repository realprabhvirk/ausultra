---
name: ausultra-design
description: Use this skill to generate well-branded interfaces and assets for AusUltra Landscaping (Brisbane landscaping/hardscaping contractor), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out of `assets/` and create static HTML files for the user to view, using the tokens in `styles.css`/`tokens/` and the component patterns in `components/`. If working on production code, copy assets and read the rules in README.md to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts or production code, depending on the need.

Note: this design system was built from a single homepage screenshot (no codebase, Figma, or font files were supplied) — see README.md's "Font substitution" and "Logo" sections before using it in production.
