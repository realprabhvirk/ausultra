Site header: logo, center nav links (active link underlined orange), phone number, and a primary "Get a Quote" CTA.

```jsx
<NavBar activeLink="Services" />
```
