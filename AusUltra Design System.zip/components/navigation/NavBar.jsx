import React from 'react';
import { Button } from '../core/Button';
import { Icon } from '../misc/Icon';

export function NavBar({ logo = '../../assets/logo.png', links = ['Home', 'Services', 'Projects', 'About', 'Contact'], activeLink = 'Home', phone = '0415 795 055' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '18px 32px', background: 'var(--color-bg)', borderBottom: 'var(--border-hairline)',
      fontFamily: 'var(--font-body)',
    }}>
      <img src={logo} alt="AusUltra Landscaping" style={{ height: 34 }} />
      <div style={{ display: 'flex', gap: 28 }}>
        {links.map((l) => (
          <a key={l} href="#" style={{
            color: l === activeLink ? 'var(--color-primary)' : '#fff',
            textDecoration: 'none', fontSize: 14, fontWeight: 500,
            borderBottom: l === activeLink ? '2px solid var(--color-primary)' : '2px solid transparent',
            paddingBottom: 4,
          }}>{l}</a>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#fff', fontSize: 14 }}>
          <Icon name="phone" size={15} color="var(--color-primary)" />
          {phone}
        </div>
        <Button variant="primary" size="sm">Get a Quote</Button>
      </div>
    </div>
  );
}
