import React from 'react';
import { Icon } from '../misc/Icon';
import { SocialIconButton } from '../misc/SocialIconButton';
import { Button } from '../core/Button';

const columns = {
  'Quick Links': ['Home', 'Services', 'Projects', 'About', 'Contact'],
  'Our Services': ['Concrete & Driveways', 'Retaining Walls', 'Front Yard Elevations', 'Backyard Transformations', 'Fencing', 'Turf Installation', 'Epoxy Coatings', 'Epoxy Flake Flooring'],
};

export function Footer({ logo = '../../assets/logo.png', phone = '0415 795 055', email = 'AusUltraLandscaping@gmail.com', location = 'Brisbane, QLD' }) {
  return (
    <div style={{ background: 'var(--color-bg)', borderTop: 'var(--border-hairline)', fontFamily: 'var(--font-body)', color: 'var(--color-text-body)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 32, padding: '48px 32px' }}>
        <div>
          <img src={logo} alt="AusUltra Landscaping" style={{ height: 32, marginBottom: 14 }} />
          <p style={{ fontSize: 13, lineHeight: 1.7, maxWidth: 260 }}>Premium landscaping, concrete, retaining walls, fencing and outdoor transformations across Brisbane.</p>
          <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
            <SocialIconButton icon="facebook" />
            <SocialIconButton icon="instagram" />
          </div>
        </div>
        {Object.entries(columns).map(([heading, items]) => (
          <div key={heading}>
            <div style={{ color: '#fff', fontWeight: 600, fontSize: 14, marginBottom: 14 }}>{heading}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {items.map((it) => <a key={it} href="#" style={{ color: 'var(--color-text-body)', fontSize: 13, textDecoration: 'none' }}>{it}</a>)}
            </div>
          </div>
        ))}
        <div>
          <div style={{ color: '#fff', fontWeight: 600, fontSize: 14, marginBottom: 14 }}>Get In Touch</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, fontSize: 13 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Icon name="phone" size={14} color="var(--color-primary)" />{phone}</div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Icon name="mail" size={14} color="var(--color-primary)" />{email}</div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Icon name="map-pin" size={14} color="var(--color-primary)" />{location}</div>
          </div>
          <div style={{ marginTop: 16 }}><Button variant="primary" size="sm">Get a Quote</Button></div>
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 32px', borderTop: 'var(--border-hairline)', fontSize: 12 }}>
        <div>© 2024 AusUltra Landscaping. All rights reserved.</div>
        <div style={{ letterSpacing: 'var(--tracking-wider)', textTransform: 'uppercase' }}>Quality Spaces. Stronger Tomorrows.</div>
      </div>
    </div>
  );
}
