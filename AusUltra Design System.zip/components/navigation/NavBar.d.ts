export interface NavBarProps {
  logo?: string;
  links?: string[];
  activeLink?: string;
  phone?: string;
}
