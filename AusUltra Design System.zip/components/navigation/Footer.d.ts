export interface FooterProps {
  logo?: string;
  phone?: string;
  email?: string;
  location?: string;
}
