Photo-topped service tile used in the "Landscaping Solutions" grid (8 services, 4-column).

```jsx
<ServiceCard image="/photos/driveway.jpg" icon="milestone" title="Concrete Sidewalks & Driveways" />
```
