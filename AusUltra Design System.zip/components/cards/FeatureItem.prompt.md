Icon-led feature row used in "More Than Landscaping" (High Quality Materials, Reliable & Professional, Local Brisbane Experts). No card container — just icon, title and one-line description stacked vertically as a list.

```jsx
<FeatureItem icon="gem" title="High Quality Materials" description="We use durable, premium materials for a long-lasting finish." />
```
