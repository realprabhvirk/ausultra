import React from 'react';
import { Icon } from '../misc/Icon';

export function ServiceCard({ image, icon, title }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        border: 'var(--border-hairline)',
        borderRadius: 'var(--radius-sm)',
        overflow: 'hidden',
        background: 'var(--color-surface)',
        cursor: 'pointer',
      }}
    >
      <div style={{ aspectRatio: '4/3', overflow: 'hidden' }}>
        <img src={image} alt={title} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Icon name={icon} size={18} color="var(--color-primary)" />
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 500, color: '#fff' }}>{title}</span>
        </div>
        <Icon
          name="arrow-right"
          size={16}
          color={hover ? 'var(--color-primary)' : 'var(--color-text-muted)'}
        />
      </div>
    </div>
  );
}
