export interface FeatureItemProps {
  icon: string;
  title: string;
  description: string;
}
