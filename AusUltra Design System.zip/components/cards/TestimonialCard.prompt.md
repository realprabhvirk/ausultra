Single testimonial card with quote glyph, star rating, generic client attribution, and prev/next circular arrow controls (the site shows one testimonial at a time behind a slider).

```jsx
<TestimonialCard quote="AusUltra did an amazing job..." author="— Brisbane Client" rating={4} />
```
