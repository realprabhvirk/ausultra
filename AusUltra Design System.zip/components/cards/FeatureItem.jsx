import React from 'react';
import { Icon } from '../misc/Icon';

export function FeatureItem({ icon, title, description }) {
  return (
    <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', fontFamily: 'var(--font-body)' }}>
      <Icon name={icon} size={26} color="var(--color-primary)" strokeWidth={1.5} />
      <div>
        <div style={{ color: '#fff', fontWeight: 600, fontSize: 15, marginBottom: 4 }}>{title}</div>
        <div style={{ color: 'var(--color-text-body)', fontSize: 13.5, lineHeight: 1.6 }}>{description}</div>
      </div>
    </div>
  );
}
