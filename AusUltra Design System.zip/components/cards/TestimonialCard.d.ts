export interface TestimonialCardProps {
  quote: string;
  author: string;
  rating?: number;
  onPrev?: () => void;
  onNext?: () => void;
}
