export interface ServiceCardProps {
  image: string;
  /** Lucide icon name representing the service */
  icon: string;
  title: string;
}
