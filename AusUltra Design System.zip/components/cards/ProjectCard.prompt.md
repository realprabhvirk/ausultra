Borderless photo tile with caption used in "Recent Projects". No card fill — just the framed photo plus title/location row below it.

```jsx
<ProjectCard image="/photos/driveway.jpg" title="Concrete Driveway" location="Brisbane, QLD" />
```
