import React from 'react';
import { Icon } from '../misc/Icon';

export function ProjectCard({ image, title, location }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ cursor: 'pointer' }}>
      <div style={{ aspectRatio: '4/3', overflow: 'hidden', borderRadius: 'var(--radius-sm)', border: 'var(--border-hairline)' }}>
        <img
          src={image}
          alt={title}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
            transform: hover ? 'scale(1.04)' : 'scale(1)',
            transition: 'transform var(--duration-base) var(--ease-standard)',
          }}
        />
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', padding: '12px 2px 0', fontFamily: 'var(--font-body)' }}>
        <div>
          <div style={{ color: '#fff', fontSize: 14, fontWeight: 500 }}>{title}</div>
          <div style={{ color: 'var(--color-text-muted)', fontSize: 12, marginTop: 2 }}>{location}</div>
        </div>
        <Icon name="arrow-right" size={16} color={hover ? 'var(--color-primary)' : 'var(--color-text-muted)'} style={{ marginTop: 3 }} />
      </div>
    </div>
  );
}
