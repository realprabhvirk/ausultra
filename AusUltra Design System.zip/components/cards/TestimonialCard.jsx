import React from 'react';
import { Icon } from '../misc/Icon';

export function TestimonialCard({ quote, author, rating = 5, onPrev, onNext }) {
  return (
    <div style={{
      background: 'var(--color-surface)',
      border: 'var(--border-hairline)',
      borderRadius: 'var(--radius-md)',
      padding: '28px 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      fontFamily: 'var(--font-body)',
      maxWidth: 460,
    }}>
      <Icon name="quote" size={22} color="var(--color-primary)" />
      <p style={{ color: 'var(--color-text-body)', fontSize: 14.5, lineHeight: 1.6, margin: 0 }}>{quote}</p>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ display: 'flex', gap: 2, marginBottom: 6 }}>
            {Array.from({ length: 5 }).map((_, i) => (
              <Icon key={i} name="star" size={14} color={i < rating ? 'var(--color-primary)' : 'var(--color-border-strong)'} />
            ))}
          </div>
          <div style={{ color: '#fff', fontSize: 13 }}>{author}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onPrev} style={{ width: 32, height: 32, borderRadius: 'var(--radius-pill)', border: '1px solid var(--color-border-strong)', background: 'transparent', color: '#fff', cursor: 'pointer' }}>
            <Icon name="arrow-left" size={14} />
          </button>
          <button onClick={onNext} style={{ width: 32, height: 32, borderRadius: 'var(--radius-pill)', border: '1px solid var(--color-border-strong)', background: 'transparent', color: '#fff', cursor: 'pointer' }}>
            <Icon name="arrow-right" size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
