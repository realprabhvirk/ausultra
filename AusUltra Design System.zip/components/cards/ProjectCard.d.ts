export interface ProjectCardProps {
  image: string;
  title: string;
  location: string;
}
