import React from 'react';
import { Icon } from './Icon';

const glyphs = {
  facebook: 'M13.5 21v-7h2.4l.4-3H13.5V9.2c0-.87.24-1.46 1.5-1.46h1.6V5.14C16.1 5.1 15.1 5 13.9 5 11.4 5 9.7 6.49 9.7 9.02V11H7.3v3h2.4v7h3.8Z',
  instagram: 'M8 3h8a5 5 0 0 1 5 5v8a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3H8Zm4 3.2A3.8 3.8 0 1 1 8.2 12 3.8 3.8 0 0 1 12 8.2Zm0 2A1.8 1.8 0 1 0 13.8 12 1.8 1.8 0 0 0 12 10.2ZM17.1 6.4a1 1 0 1 1-1 1 1 1 0 0 1 1-1Z',
};

export function SocialIconButton({ icon, href = '#' }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a
      href={href}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: 36,
        height: 36,
        borderRadius: 'var(--radius-pill)',
        border: '1px solid var(--color-border-strong)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: hover ? 'var(--color-primary)' : 'transparent',
        borderColor: hover ? 'var(--color-primary)' : 'var(--color-border-strong)',
        transition: 'background var(--duration-fast) var(--ease-standard)',
      }}
    >
      {glyphs[icon] ? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill={hover ? '#1a1210' : '#fff'}>
          <path d={glyphs[icon]} />
        </svg>
      ) : (
        <Icon name={icon} size={16} color={hover ? '#1a1210' : '#fff'} />
      )}
    </a>
  );
}
