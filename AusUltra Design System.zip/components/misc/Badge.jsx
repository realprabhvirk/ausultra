import React from 'react';
import { Icon } from './Icon';

export function Badge({ icon, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-body)' }}>
      <Icon name={icon} size={20} color="var(--color-primary)" />
      <span style={{ color: '#fff', fontSize: 13, lineHeight: 1.3 }}>{children}</span>
    </div>
  );
}
