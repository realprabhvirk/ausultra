Renders a brand icon using the Lucide outline set (substituted CDN icon set — no icon font/SVG sprite was provided in the source).

```jsx
<Icon name="shield-check" size={22} color="var(--color-primary)" />
```

Requires the consuming page to load `<script src="https://unpkg.com/lucide@latest"></script>` in `<head>` — Icon calls `window.lucide.createIcons()` on mount/update. Use outline-only names (no filled variants) to match the brand's stroke-only icon style.
