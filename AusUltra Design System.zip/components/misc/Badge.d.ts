export interface BadgeProps {
  /** Lucide icon name, e.g. "shield-check", "calendar", "users" */
  icon: string;
  children: React.ReactNode;
}
