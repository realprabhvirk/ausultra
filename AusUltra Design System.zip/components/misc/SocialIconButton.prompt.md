Circular outline social-link button used in the footer.

```jsx
<SocialIconButton icon="facebook" href="https://facebook.com/ausultra" />
```
