Icon + label pill used in the hero trust strip ("Quality Workmanship", "On Time & Reliable", "Local Brisbane Business"). Not a bordered chip — just icon and text side by side.

```jsx
<Badge icon="shield-check">Quality Workmanship</Badge>
```
