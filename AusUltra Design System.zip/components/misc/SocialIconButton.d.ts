export interface SocialIconButtonProps {
  /** Lucide icon name, e.g. "facebook", "instagram" */
  icon: string;
  href?: string;
}
