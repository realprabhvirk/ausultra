import React from 'react';

export function Icon({ name, size = 20, color = 'currentColor', strokeWidth = 1.75, style }) {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [name]);
  return (
    <i
      data-lucide={name}
      style={{ width: size, height: size, color, display: 'inline-block', ...style }}
      data-stroke-width={strokeWidth}
    ></i>
  );
}
