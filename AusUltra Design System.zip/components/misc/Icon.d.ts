export interface IconProps {
  /** Lucide icon name, e.g. "shield-check", "calendar", "users", "gem", "handshake", "map-pin", "arrow-right", "phone", "mail", "facebook", "instagram", "layers", "grid-2x2", "sprout", "fence" */
  name: string;
  /** Pixel size, square. Default 20. */
  size?: number;
  /** Stroke color. Default currentColor. */
  color?: string;
  strokeWidth?: number;
  style?: React.CSSProperties;
}
