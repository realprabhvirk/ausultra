export interface ButtonProps {
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md';
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  /** Lucide icon name for the trailing icon, or falsy to omit. Default "arrow-right". */
  icon?: string | false;
  children: React.ReactNode;
}
