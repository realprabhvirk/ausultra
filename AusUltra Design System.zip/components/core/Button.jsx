import React from 'react';
import { Icon } from '../misc/Icon';

export function Button({ variant = 'primary', size = 'md', href, onClick, disabled, icon = 'arrow-right', children }) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 10,
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: size === 'sm' ? 13 : 14,
    padding: size === 'sm' ? '10px 18px' : '14px 24px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    textDecoration: 'none',
    transition: 'background var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)',
  };
  const variants = {
    primary: {
      background: 'var(--color-primary)',
      color: '#1a1210',
      borderColor: 'var(--color-primary)',
    },
    secondary: {
      background: 'transparent',
      color: '#fff',
      borderColor: 'var(--color-border-strong)',
    },
  };
  const hover = {
    primary: { background: 'var(--color-primary-hover)', borderColor: 'var(--color-primary-hover)' },
    secondary: { background: 'var(--color-surface)', borderColor: '#fff' },
  };
  const [isHover, setHover] = React.useState(false);
  const style = { ...base, ...variants[variant], ...(isHover && !disabled ? hover[variant] : {}) };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag
      href={href}
      onClick={disabled ? undefined : onClick}
      disabled={Tag === 'button' ? disabled : undefined}
      style={style}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {children}
      {icon ? <Icon name={icon} size={16} /> : null}
    </Tag>
  );
}
