Primary CTA button (solid orange) and secondary button (outline) with a trailing arrow icon, used throughout the site for "Get a Free Quote", "View Our Work", "About Us", etc.

```jsx
<Button variant="primary">Get a Free Quote</Button>
<Button variant="secondary" icon="play">View Our Work</Button>
```

Variants: `primary` (solid fill), `secondary` (1px outline, transparent). Sizes: `sm`, `md`. Pass `icon={false}` to omit the trailing arrow.
