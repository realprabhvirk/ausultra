const { NavBar, Footer, Badge, ServiceCard, ProjectCard, FeatureItem, TestimonialCard, Button, Icon } = window.AusUltraDesignSystem_98e6b4;

const services = [
  { icon: 'milestone', title: 'Concrete Sidewalks & Driveways', image: '../../assets/project-driveway.jpg' },
  { icon: 'brick-wall', title: 'Retaining Walls', image: '../../assets/project-retaining-wall.jpg' },
  { icon: 'home', title: 'House Front Elevations', image: '../../assets/hero-photo.jpg' },
  { icon: 'trees', title: 'Backyard Transformation', image: '../../assets/hero-photo.jpg' },
  { icon: 'fence', title: 'Timber & Colorbond Fencing', image: '../../assets/project-retaining-wall.jpg' },
  { icon: 'sprout', title: 'Artificial/Natural Turf Installation', image: '../../assets/texture-pathway.jpg' },
  { icon: 'layers', title: 'Epoxy Coatings', image: '../../assets/project-driveway.jpg' },
  { icon: 'grid-2x2', title: 'Epoxy Flake Flooring', image: '../../assets/project-driveway.jpg' },
];

const projects = [
  { title: 'Concrete Driveway', location: 'Brisbane, QLD', image: '../../assets/project-driveway.jpg' },
  { title: 'Retaining Wall', location: 'Brisbane, QLD', image: '../../assets/project-retaining-wall.jpg' },
  { title: 'Backyard Transformation', location: 'Brisbane, QLD', image: '../../assets/hero-photo.jpg' },
  { title: 'Turf Installation', location: 'Brisbane, QLD', image: '../../assets/texture-pathway.jpg' },
];

const testimonials = [
  { quote: 'AusUltra did an amazing job on our backyard. Professional, reliable and the quality is top notch. Highly recommend!', author: '— Brisbane Client', rating: 4 },
  { quote: 'From the quote to the finished driveway, everything was on time and exactly as promised. Couldn\u2019t be happier.', author: '— Brisbane Client', rating: 5 },
  { quote: 'Our retaining wall looks incredible and the whole crew was easy to deal with from start to finish.', author: '— Brisbane Client', rating: 5 },
];

function Homepage() {
  const [tIndex, setTIndex] = React.useState(0);
  const t = testimonials[tIndex];
  const next = () => setTIndex((i) => (i + 1) % testimonials.length);
  const prev = () => setTIndex((i) => (i - 1 + testimonials.length) % testimonials.length);

  const section = { padding: '72px 32px', maxWidth: 1280, margin: '0 auto' };
  const eyebrow = { fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, letterSpacing: 'var(--tracking-wider)', textTransform: 'uppercase', color: 'var(--color-primary)', marginBottom: 12 };
  const h2 = { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(1.6rem,3vw,2.1rem)', lineHeight: 1.1, textTransform: 'uppercase', color: '#fff', margin: 0 };

  return (
    <div style={{ background: 'var(--color-bg)', minHeight: '100vh' }}>
      <NavBar activeLink="Home" />

      <div style={{ position: 'relative', padding: '56px 32px 64px', maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, alignItems: 'center' }}>
        <div>
          <div style={eyebrow}>Brisbane Landscaping Experts</div>
          <h1 style={{ ...h2, fontSize: 'clamp(2rem,4.5vw,3.1rem)', marginBottom: 20 }}>Transforming<br /><span style={{ color: 'var(--color-primary)' }}>Outdoor Spaces.</span></h1>
          <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-body)', fontSize: 15.5, lineHeight: 1.7, maxWidth: 440, marginBottom: 32 }}>Concrete, retaining walls, fencing, turf and complete landscaping solutions. Built to last.</p>
          <div style={{ display: 'flex', gap: 14, marginBottom: 44 }}>
            <Button variant="primary">Get a Free Quote</Button>
            <Button variant="secondary" icon="play">View Our Work</Button>
          </div>
          <div style={{ display: 'flex', gap: 36 }}>
            <Badge icon="shield-check">Quality Workmanship</Badge>
            <Badge icon="calendar">On Time & Reliable</Badge>
            <Badge icon="users">Local Brisbane Business</Badge>
          </div>
        </div>
        <div style={{ borderRadius: 'var(--radius-md)', overflow: 'hidden', border: 'var(--border-hairline)' }}>
          <img src="../../assets/hero-photo.jpg" alt="Landscaped outdoor steps" style={{ width: '100%', display: 'block' }} />
        </div>
      </div>

      <div style={section}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 40, gap: 24 }}>
          <div>
            <div style={eyebrow}>Our Services</div>
            <h2 style={h2}>Landscaping<br />Solutions<br />Built For You.</h2>
          </div>
          <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-body)', fontSize: 14, maxWidth: 320, lineHeight: 1.6 }}>From concrete driveways to complete backyard transformations, AusUltra Landscaping delivers high-quality, functional and modern outdoor spaces across Brisbane and surrounding areas.</p>
          <Button variant="secondary" size="sm">View All Services</Button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 20 }}>
          {services.map((s) => <ServiceCard key={s.title} {...s} />)}
        </div>
      </div>

      <div style={{ ...section, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}>
        <div>
          <div style={eyebrow}>Why Choose AusUltra</div>
          <h2 style={{ ...h2, marginBottom: 18 }}>More Than<br />Landscaping.</h2>
          <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-body)', fontSize: 14.5, lineHeight: 1.7, marginBottom: 14 }}>We take pride in delivering high-quality landscaping solutions that enhance your home, add value and are built to last.</p>
          <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-body)', fontSize: 14.5, lineHeight: 1.7, marginBottom: 28 }}>From concept to completion, we focus on quality, reliability and attention to detail.</p>
          <Button variant="secondary" size="sm">About Us</Button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 26 }}>
          <FeatureItem icon="gem" title="High Quality Materials" description="We use durable, premium materials for a long-lasting finish." />
          <FeatureItem icon="handshake" title="Reliable & Professional" description="Clear communication and on-time delivery." />
          <FeatureItem icon="map-pin" title="Local Brisbane Experts" description="Proudly serving Brisbane and surrounding areas." />
        </div>
      </div>

      <div style={section}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
          <div>
            <div style={eyebrow}>Our Work</div>
            <h2 style={h2}>Recent <span style={{ color: 'var(--color-primary)' }}>Projects</span></h2>
            <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-body)', fontSize: 14, marginTop: 10 }}>See the difference a well-designed outdoor space can make.</p>
          </div>
          <Button variant="secondary" size="sm">View All Projects</Button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 20 }}>
          {projects.map((p) => <ProjectCard key={p.title} {...p} />)}
        </div>
      </div>

      <div style={{ ...section, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}>
        <div>
          <div style={eyebrow}>What Our Clients Say</div>
          <h2 style={h2}>Trusted By<br /><span style={{ color: 'var(--color-primary)' }}>Brisbane Homeowners.</span></h2>
        </div>
        <TestimonialCard {...t} onPrev={prev} onNext={next} />
      </div>

      <Footer />
    </div>
  );
}
window.Homepage = Homepage;
